DROP TABLE Results;
DROP TABLE Competitions;
DROP TABLE Sports;
DROP TABLE People;
DROP TABLE Gender;
